package com.betuly.restcountries;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.betuly.Service.ApiService;
import com.betuly.Starter.RestcountriesApplication;
import com.betuly.model.Country;

@SpringBootTest(classes = {RestcountriesApplication.class})
class RestcountriesApplicationTests {
	
	@Autowired
	private ApiService apiService;
	
	@BeforeEach
	public void beforeEach() {
		System.out.println("Test Başladı");
	}

	@Test
	public void TestgetCountryByName() {
		List<Country> countryByName = apiService.getCountryByName("Turkey");
		if (countryByName != null) {
			System.out.print(countryByName);
		}
		else {
			System.out.print("Ülke Bulunamadı");
		}
	}
	
	@Test
	public void TestgetCountryByRegion() {
		List<Country> countryByRegion = apiService.getCountryByRegion("Australia");
		if (countryByRegion != null) {
			System.out.print(countryByRegion);
		}
		else {
			System.out.print("Ülke Bulunamadı");
		}
	}
	
	@Test
	public void TestgetCountryByCapital() {
		List<Country> countryByCapital = apiService.getCountryByCapital("Ankara");
		if (countryByCapital != null) {
			System.out.print(countryByCapital);
		}
		else {
			System.out.print("Ülke Bulunamadı");
		}
	}
	
	@Test
	public void TestgetCountryByLanguage() {
		List<Country> countryByLanguage = apiService.getCountryByLanguage("spanish");
		if (countryByLanguage != null) {
			System.out.print(countryByLanguage);
		}
		else {
			System.out.print("Ülke Bulunamadı");
		}
	}

}
