package dto;

import org.springframework.stereotype.Service;

import com.betuly.model.Name;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DtoRegion {
	Name name;
	int population;
}
