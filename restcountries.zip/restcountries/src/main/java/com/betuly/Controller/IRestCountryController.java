package com.betuly.Controller;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.betuly.Controller.impl.RootEntity;
import com.betuly.model.Country;

import dto.DtoRegion;

public interface IRestCountryController {
	
	public RootEntity<List<Country>>  getCountryByName(String name);

	public RootEntity<List<Country>>  getAllCountry();
	
	public RootEntity<List<Country>>  getCountryByRegion(String name);
	
	public RootEntity<List<Country>>  getCountryByLanguage(String name);
	
	public RootEntity<List<Country>>  getCountryByCapital(String name);
}
