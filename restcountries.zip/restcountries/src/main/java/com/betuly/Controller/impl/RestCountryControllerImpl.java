package com.betuly.Controller.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.betuly.Controller.IRestCountryController;
import com.betuly.Service.ApiService;
import com.betuly.model.Country;

import dto.DtoRegion;

@RestController
public class RestCountryControllerImpl extends RestBaseController implements IRestCountryController{
	
	@Autowired
	ApiService apiService;
	
	@GetMapping("/name")
	public RootEntity<List<Country>> getCountryByName(@RequestParam String name) {
		return ok(apiService.getCountryByName(name));
	}
	
	@GetMapping("/all")
	public RootEntity<List<Country>> getAllCountry(){
		return ok(apiService.getAllCountry());
	}
	
	@GetMapping("/region")
	public RootEntity<List<Country>> getCountryByRegion(@RequestParam String name){
		return ok(apiService.getCountryByRegion(name));
	}
	
	@GetMapping("/lang")
	public RootEntity<List<Country>> getCountryByLanguage(@RequestParam String name){
		return ok(apiService.getCountryByLanguage(name));
	}
	
	@GetMapping("/capital")
	public RootEntity<List<Country>> getCountryByCapital(@RequestParam String name){
		return ok(apiService.getCountryByCapital(name));
	}

}
