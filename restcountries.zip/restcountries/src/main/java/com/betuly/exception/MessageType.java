package com.betuly.exception;

import lombok.Getter;

@Getter
public enum MessageType {
	
	NO_RECORD_EXIST("1004", "Kayıt Bulunmadı"),
	CURRENCY_RATES_IS_OCCURED("1010","Veri alınırken bir hata oluştu"),
	GENERAL_EXCEPTION("9999", "Genel Hata Oluştu");
	
	
	private String code;
	
	private String message;
	
	MessageType(String code, String message) {
		this.code = code;
		this.message = message;
	}

}
