package com.betuly.model;

import lombok.Data;

@Data
public class Flags {

	private String png;
	private String alt;
}
