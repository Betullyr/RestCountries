package com.betuly.model;

import lombok.Data;


@Data
public class Capital {

	private String capitals;
}
