package com.betuly.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true) 
@Data
public class Name {
	
   private String common;
   private String official;
}
