package com.betuly.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Country {
	
	Name name;
	List<String> capital;
	Flags flags;
	int population;
	
}
