package com.betuly.Starter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

@EntityScan(basePackages = {"com.betuly"})
@ComponentScan(basePackages = {"com.betuly"})
@SpringBootApplication
public class RestcountriesApplication {
	
	@Bean
	public RestTemplate restTemplate() {
	  return new RestTemplate();
	}

	@Bean
	public HttpHeaders httpHeaders() {
	  return new HttpHeaders();
	}

	public static void main(String[] args) {
		SpringApplication.run(RestcountriesApplication.class, args);
	}

}
