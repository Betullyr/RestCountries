package com.betuly.Service.Impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.betuly.Service.ApiService;
import com.betuly.exception.BaseException;
import com.betuly.exception.ErrorMessage;
import com.betuly.exception.MessageType;
import com.betuly.model.Country;

import dto.DtoRegion;

@Service
public class ApiServiceImpl implements ApiService{
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private HttpHeaders httpHeaders;
	
	String rootUrl = "https://restcountries.com/v3.1";
	
	
	private <T> T sendRequest(String url, ParameterizedTypeReference<T> responseType) {
		HttpEntity<?> httpEntity = new HttpEntity<>(httpHeaders);
		try {
			
			ResponseEntity<T> response = restTemplate.exchange(
		            url,
		            HttpMethod.GET,
		            httpEntity,
		            responseType
		    );
			if (response.getStatusCode().is2xxSuccessful()) {
				return response.getBody();
			}
			
		} catch (Exception e) {
		   throw new BaseException(new ErrorMessage(MessageType.CURRENCY_RATES_IS_OCCURED,e.getMessage()));
		}
		return null;
		
	}
	

	public List<Country> getCountryByName(String name) {
		
	  String url = rootUrl + "/name/" + name;
	  
	  return sendRequest(url, new ParameterizedTypeReference<List<Country>>() {});
	}


	@Override
	public List<Country> getAllCountry() {
		
		String url = rootUrl + "/all";
		
		return sendRequest(url, new ParameterizedTypeReference<List<Country>>() {});
	}
	
	public List<Country> getCountryByRegion(String name){
		
		List<DtoRegion> regions = new ArrayList<>();
		DtoRegion region = new DtoRegion();
		
		String url = rootUrl + "/region/" + name;
		return sendRequest(url, new ParameterizedTypeReference<List<Country>>() {}).subList(0, 5);
		
		/*for (Country country : countries) {
			region.setName(countries.get(0).getName());
			region.setPopulation(countries.get(0).getPopulation());
			regions.add(region);
		}		
				return regions;
	  */

	}
	
	public List<Country> getCountryByLanguage(String name){
		
       String url = rootUrl + "/lang/" + name;
		
	   return sendRequest(url, new ParameterizedTypeReference<List<Country>>() {});
		
	}
	
	
	public List<Country> getCountryByCapital(String name){
		
		String url = rootUrl + "/capital/" + name;
		
	    return sendRequest(url, new ParameterizedTypeReference<List<Country>>() {});
		
	}

}
