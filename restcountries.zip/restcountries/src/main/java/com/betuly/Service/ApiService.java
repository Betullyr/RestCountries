package com.betuly.Service;

import java.util.List;

import com.betuly.model.Country;

import dto.DtoRegion;

public interface ApiService {
	
	public List<Country> getCountryByName(String name);
	public List<Country> getAllCountry();
	public List<Country> getCountryByRegion(String name);
	public List<Country> getCountryByLanguage(String name);
	public List<Country> getCountryByCapital(String name);

}
